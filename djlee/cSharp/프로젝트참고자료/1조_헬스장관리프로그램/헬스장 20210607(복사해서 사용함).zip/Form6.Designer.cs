﻿
namespace 헬스장프로그램
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tel = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_WOC7 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC8 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC9 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC67 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC10 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC11 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC3 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC4 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC5 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC2 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC1 = new ePOSOne.btnProduct.Button_WOC();
            this.b1 = new ePOSOne.btnProduct.Button_WOC();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label3.Location = new System.Drawing.Point(930, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 19);
            this.label3.TabIndex = 16;
            this.label3.Text = "tt 00:00:00";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Orange;
            this.label7.Location = new System.Drawing.Point(187, 127);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(174, 33);
            this.label7.TabIndex = 32;
            this.label7.Text = "ENTRANCE";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 39.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Orange;
            this.label6.Location = new System.Drawing.Point(256, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 61);
            this.label6.TabIndex = 31;
            this.label6.Text = "입장";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 39.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Orange;
            this.label1.Location = new System.Drawing.Point(180, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 61);
            this.label1.TabIndex = 30;
            this.label1.Text = "02";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(399, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 24);
            this.label2.TabIndex = 55;
            this.label2.Text = "연  락  처";
            // 
            // tel
            // 
            this.tel.Font = new System.Drawing.Font("굴림", 15F);
            this.tel.Location = new System.Drawing.Point(488, 94);
            this.tel.Margin = new System.Windows.Forms.Padding(5);
            this.tel.MaxLength = 11;
            this.tel.Name = "tel";
            this.tel.Size = new System.Drawing.Size(170, 30);
            this.tel.TabIndex = 50;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Orange;
            this.label4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Transparent;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.label4.Location = new System.Drawing.Point(750, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 33);
            this.label4.TabIndex = 57;
            this.label4.Text = "입   력";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Orange;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Font = new System.Drawing.Font("굴림", 15F);
            this.button4.Location = new System.Drawing.Point(710, 78);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(160, 57);
            this.button4.TabIndex = 56;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::헬스장프로그램.Properties.Resources.홈으로_아이콘4_더작은거_;
            this.pictureBox1.Location = new System.Drawing.Point(23, 515);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 81);
            this.pictureBox1.TabIndex = 68;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // button_WOC7
            // 
            this.button_WOC7.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC7.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC7.FlatAppearance.BorderSize = 0;
            this.button_WOC7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC7.Font = new System.Drawing.Font("돋움체", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC7.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC7.Location = new System.Drawing.Point(600, 431);
            this.button_WOC7.Name = "button_WOC7";
            this.button_WOC7.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC7.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC7.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC7.Size = new System.Drawing.Size(83, 67);
            this.button_WOC7.TabIndex = 67;
            this.button_WOC7.Text = "전체\r\n삭제";
            this.button_WOC7.TextColor = System.Drawing.Color.White;
            this.button_WOC7.UseVisualStyleBackColor = true;
            this.button_WOC7.Click += new System.EventHandler(this.button_WOC7_Click);
            // 
            // button_WOC8
            // 
            this.button_WOC8.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC8.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC8.FlatAppearance.BorderSize = 0;
            this.button_WOC8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC8.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC8.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC8.Location = new System.Drawing.Point(495, 431);
            this.button_WOC8.Name = "button_WOC8";
            this.button_WOC8.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC8.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC8.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC8.Size = new System.Drawing.Size(83, 67);
            this.button_WOC8.TabIndex = 66;
            this.button_WOC8.Text = "0";
            this.button_WOC8.TextColor = System.Drawing.Color.White;
            this.button_WOC8.UseVisualStyleBackColor = true;
            this.button_WOC8.Click += new System.EventHandler(this.button_WOC8_Click);
            // 
            // button_WOC9
            // 
            this.button_WOC9.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC9.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC9.FlatAppearance.BorderSize = 0;
            this.button_WOC9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC9.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC9.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC9.Location = new System.Drawing.Point(600, 343);
            this.button_WOC9.Name = "button_WOC9";
            this.button_WOC9.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC9.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC9.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC9.Size = new System.Drawing.Size(83, 67);
            this.button_WOC9.TabIndex = 65;
            this.button_WOC9.Text = "9";
            this.button_WOC9.TextColor = System.Drawing.Color.White;
            this.button_WOC9.UseVisualStyleBackColor = true;
            this.button_WOC9.Click += new System.EventHandler(this.button_WOC9_Click);
            // 
            // button_WOC67
            // 
            this.button_WOC67.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC67.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC67.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC67.FlatAppearance.BorderSize = 0;
            this.button_WOC67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC67.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC67.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC67.Location = new System.Drawing.Point(495, 343);
            this.button_WOC67.Name = "button_WOC67";
            this.button_WOC67.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC67.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC67.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC67.Size = new System.Drawing.Size(83, 67);
            this.button_WOC67.TabIndex = 64;
            this.button_WOC67.Text = "8";
            this.button_WOC67.TextColor = System.Drawing.Color.White;
            this.button_WOC67.UseVisualStyleBackColor = true;
            this.button_WOC67.Click += new System.EventHandler(this.button_WOC67_Click);
            // 
            // button_WOC10
            // 
            this.button_WOC10.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC10.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC10.FlatAppearance.BorderSize = 0;
            this.button_WOC10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC10.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC10.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC10.Location = new System.Drawing.Point(391, 431);
            this.button_WOC10.Name = "button_WOC10";
            this.button_WOC10.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC10.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC10.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC10.Size = new System.Drawing.Size(83, 67);
            this.button_WOC10.TabIndex = 64;
            this.button_WOC10.Text = "010";
            this.button_WOC10.TextColor = System.Drawing.Color.White;
            this.button_WOC10.UseVisualStyleBackColor = true;
            this.button_WOC10.Click += new System.EventHandler(this.button_WOC10_Click);
            // 
            // button_WOC11
            // 
            this.button_WOC11.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC11.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC11.FlatAppearance.BorderSize = 0;
            this.button_WOC11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC11.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC11.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC11.Location = new System.Drawing.Point(393, 343);
            this.button_WOC11.Name = "button_WOC11";
            this.button_WOC11.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC11.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC11.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC11.Size = new System.Drawing.Size(83, 67);
            this.button_WOC11.TabIndex = 63;
            this.button_WOC11.Text = "7";
            this.button_WOC11.TextColor = System.Drawing.Color.White;
            this.button_WOC11.UseVisualStyleBackColor = true;
            this.button_WOC11.Click += new System.EventHandler(this.button_WOC11_Click_1);
            // 
            // button_WOC3
            // 
            this.button_WOC3.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC3.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC3.FlatAppearance.BorderSize = 0;
            this.button_WOC3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC3.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC3.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC3.Location = new System.Drawing.Point(600, 257);
            this.button_WOC3.Name = "button_WOC3";
            this.button_WOC3.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC3.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC3.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC3.Size = new System.Drawing.Size(83, 67);
            this.button_WOC3.TabIndex = 62;
            this.button_WOC3.Text = "6";
            this.button_WOC3.TextColor = System.Drawing.Color.White;
            this.button_WOC3.UseVisualStyleBackColor = true;
            this.button_WOC3.Click += new System.EventHandler(this.button_WOC3_Click);
            // 
            // button_WOC4
            // 
            this.button_WOC4.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC4.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC4.FlatAppearance.BorderSize = 0;
            this.button_WOC4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC4.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC4.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC4.Location = new System.Drawing.Point(495, 257);
            this.button_WOC4.Name = "button_WOC4";
            this.button_WOC4.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC4.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC4.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC4.Size = new System.Drawing.Size(83, 67);
            this.button_WOC4.TabIndex = 61;
            this.button_WOC4.Text = "5";
            this.button_WOC4.TextColor = System.Drawing.Color.White;
            this.button_WOC4.UseVisualStyleBackColor = true;
            this.button_WOC4.Click += new System.EventHandler(this.button_WOC4_Click);
            // 
            // button_WOC5
            // 
            this.button_WOC5.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC5.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC5.FlatAppearance.BorderSize = 0;
            this.button_WOC5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC5.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC5.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC5.Location = new System.Drawing.Point(393, 257);
            this.button_WOC5.Name = "button_WOC5";
            this.button_WOC5.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC5.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC5.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC5.Size = new System.Drawing.Size(83, 67);
            this.button_WOC5.TabIndex = 60;
            this.button_WOC5.Text = "4";
            this.button_WOC5.TextColor = System.Drawing.Color.White;
            this.button_WOC5.UseVisualStyleBackColor = true;
            this.button_WOC5.Click += new System.EventHandler(this.button_WOC5_Click);
            // 
            // button_WOC2
            // 
            this.button_WOC2.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC2.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC2.FlatAppearance.BorderSize = 0;
            this.button_WOC2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC2.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC2.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC2.Location = new System.Drawing.Point(600, 171);
            this.button_WOC2.Name = "button_WOC2";
            this.button_WOC2.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC2.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC2.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC2.Size = new System.Drawing.Size(83, 67);
            this.button_WOC2.TabIndex = 59;
            this.button_WOC2.Text = "3";
            this.button_WOC2.TextColor = System.Drawing.Color.White;
            this.button_WOC2.UseVisualStyleBackColor = true;
            this.button_WOC2.Click += new System.EventHandler(this.button_WOC2_Click);
            // 
            // button_WOC1
            // 
            this.button_WOC1.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC1.ButtonColor = System.Drawing.Color.Orange;
            this.button_WOC1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WOC1.FlatAppearance.BorderSize = 0;
            this.button_WOC1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC1.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_WOC1.ForeColor = System.Drawing.Color.Orange;
            this.button_WOC1.Location = new System.Drawing.Point(495, 171);
            this.button_WOC1.Name = "button_WOC1";
            this.button_WOC1.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.button_WOC1.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.button_WOC1.OnHoverTextColor = System.Drawing.Color.Gray;
            this.button_WOC1.Size = new System.Drawing.Size(83, 67);
            this.button_WOC1.TabIndex = 58;
            this.button_WOC1.Text = "2";
            this.button_WOC1.TextColor = System.Drawing.Color.White;
            this.button_WOC1.UseVisualStyleBackColor = true;
            this.button_WOC1.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // b1
            // 
            this.b1.BorderColor = System.Drawing.Color.Orange;
            this.b1.ButtonColor = System.Drawing.Color.Orange;
            this.b1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.b1.FlatAppearance.BorderSize = 0;
            this.b1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b1.Font = new System.Drawing.Font("돋움체", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.b1.ForeColor = System.Drawing.Color.Orange;
            this.b1.Location = new System.Drawing.Point(393, 171);
            this.b1.Name = "b1";
            this.b1.OnHoverBorderColor = System.Drawing.Color.Gray;
            this.b1.OnHoverButtonColor = System.Drawing.Color.Yellow;
            this.b1.OnHoverTextColor = System.Drawing.Color.Gray;
            this.b1.Size = new System.Drawing.Size(83, 67);
            this.b1.TabIndex = 0;
            this.b1.Text = "1";
            this.b1.TextColor = System.Drawing.Color.White;
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // Form6
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1060, 615);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_WOC7);
            this.Controls.Add(this.button_WOC8);
            this.Controls.Add(this.button_WOC9);
            this.Controls.Add(this.button_WOC67);
            this.Controls.Add(this.button_WOC10);
            this.Controls.Add(this.button_WOC11);
            this.Controls.Add(this.button_WOC3);
            this.Controls.Add(this.button_WOC4);
            this.Controls.Add(this.button_WOC5);
            this.Controls.Add(this.button_WOC2);
            this.Controls.Add(this.button_WOC1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.b1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ePOSOne.btnProduct.Button_WOC b1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button4;
        private ePOSOne.btnProduct.Button_WOC button_WOC1;
        private ePOSOne.btnProduct.Button_WOC button_WOC2;
        private ePOSOne.btnProduct.Button_WOC button_WOC3;
        private ePOSOne.btnProduct.Button_WOC button_WOC4;
        private ePOSOne.btnProduct.Button_WOC button_WOC5;
        private ePOSOne.btnProduct.Button_WOC button_WOC7;
        private ePOSOne.btnProduct.Button_WOC button_WOC8;
        private ePOSOne.btnProduct.Button_WOC button_WOC9;
        private ePOSOne.btnProduct.Button_WOC button_WOC10;
        private ePOSOne.btnProduct.Button_WOC button_WOC11;
        private System.Windows.Forms.PictureBox pictureBox1;
        private ePOSOne.btnProduct.Button_WOC button_WOC67;
    }
}