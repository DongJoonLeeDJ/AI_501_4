
import pymysql


my_db = pymysql.connect(
    # user='root',
    # password='1234',
    # host='localhost',
    # db='aa'
    # charset='utf8'
    user='newruh',
    password='Ps3xbox360!',
    host='newruh.cafe24.com',
    db='newruh',
    charset='utf8'



)

cursor=my_db.cursor(pymysql.cursors.SSCursor)
sql="SELECT * from cvd_19"
cursor.execute(sql)
result = cursor.fetchall()
print(result)

